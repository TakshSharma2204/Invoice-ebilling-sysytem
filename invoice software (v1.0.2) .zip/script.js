  let table = document.getElementById('mainspace')
  let genrateButton = document.getElementById('gen-invoice')
  let date = document.getElementById("date").value
  var invoice;
  var amount2 = 0;
  var total = 0;
  let shippingCharge = 50
  var mainList = []
  var list = {}


function print(){
      var button = document.getElementById("download")
      invoice += button
  }

  function add() {

      let amount = document.getElementById('amount');
      let rate = document.getElementById('rate')
      let quantity = document.getElementById('quantity')
      let result = document.getElementById('AMT')
      amount.value = rate.value * quantity.value
      result.innerText = amount.value
      total += amount.value
      let item = document.getElementById('Article')
      var itemname = item.value
      var price = rate.value
      if (itemname !== '' && price !== '' && quantity.value !== '') {

          list = {
              "itemName": itemname,
              "quantity": quantity.value,
              "rate": parseFloat(rate.value).toFixed(2),
              "amount" : amount.value
          }
          
          mainList.push(list)
      }
      table.innerHTML += `<tr> <td>` + itemname + `</td> <td>` + quantity.value + `</td> <td>` + price + `</td> <td>` + amount.value + `</td> </tr>`
      item.value = '';
      rate.value = '';
      quantity.value = '';
      setTimeout(()=>{
      result.innerText = '';
      }, 5000)
  }




  function genZ() {

      let name = document.getElementById("Name")
      let address = document.getElementById("address")
      let contact = document.getElementById("contact")
      let mail = document.getElementById("mail")
      let billNo = document.getElementById("BillNo")
      let date = document.getElementById("date").value

      invoice = `
      
      
      
      
    <html>
    <title>Invoice</title>
  <link rel="stylesheet" href="media.css" media="print">
  
    
    <style>
    
    
    
    body {
    background-color: rgb(204, 204, 204)
}


.linesBottom {
    border-bottom: 1px solid black;
}

* {
    font-weight: bold;
    font-size: 20px;
    padding: 0px;
    margin: 0px;
}

.flex {
    display: flex;
}

.abs {
    position: absolute;
}

.foritems {
    padding: 2px 0px 2px 60px;
    font-size: 19px;
    font-weight: lighter;
}

.pright {
    padding-right: 80px;
}

.pleft {
    padding-left: 80px;
}

.invoiceImg {
    display: flex;
    justify-content: flex-end;
}




.total{
    padding-top: 15px;
    font-size: 22px; 
    
}


.invoice {
    height: 55px;
    padding: 25px 25px;
}

.page {
    background-color: white;
    position: relative;
    overflow: hidden;
    margin: 40px auto;
    display: block;
    box-shadow: 5px 2px 9px 5px gray;
}

.page[size="A4"] {
    width: 21cm;
    height: 32cm;
}


.yoursupplier {
    position: absolute;
    top: 80px;
    font-size: 24px;
}

.companyname {
    color: skyblue;
    font-size: 25px;
    font-weight: bolder;
    position: absolute;
    top: 120px;

}

.addr {
    position: absolute;
    top: 160px;
    font-size: 15px;
}

.mail {
    top: 195px;
    font-size: 15px;
    line-height: 25px;
}

.client {
    top: 80px;
    font-size: 24px;
    left: 500px;
}

.supplied {
    font-size: 25px;
    color: skyblue;
    top: 120px;
    left: 500px;
}

.caddr {
    top: 160px;
    font-size: 14px;
    left: 500px;
}

.mail2 {
    top: 200px;
    left: 500px;
    font-size: 15px;
    line-height: 25px;
}

.indiapost {
    height: 100px;
    bottom: 230px;
}

.BILL {
    top: 22rem;
}

hr {
    position: relative;
    width: 70%;
    margin: 0px auto;
}


.hr {
    position: relative;
    top: 880px;
    border: 1px solid black;
    width: 70%;
    margin: 0px auto;
}

.maintable {
    position: relative;
    top: 16rem;
    background-color: deepskyblue;
    margin: 0px auto;
    width: 85%;
    font-weight: lighter;
}


.mainTR th {
    padding-left: 40px;
    padding-right: 10px;
}


.upperhr {
    position: relative;
    top: 30px;
    margin: 0px auto;
    border: 0.001cm solid black;
}

.bottomHR {
    position: relative;
    top: 265px;
    border: 1px solid black;
}

.datewala {
    position: absolute;
    top: 22rem;
    right: 140px;
}

.left {
    position: relative;
    top: -10px;
}

.right {
    position: relative;
    top: -10px;
    
}

.mainTH {
    padding: 11px 0px;
    color: white;
}

.pineLogo {
    width: 120px;
    padding-left: 20;
    margin: 0;
}

.images{
    display: flex;
    justify-content: space-between;
    margin-top: 40px;
}

.track{
    bottom: 180px;
    font-size:17px;
    font-weight: lighter;
    line-height: 24px;
    
}

.list .liS{
    
    font-weight: lighter;
}

.list{
    font-size: 15px;
    bottom: 30px;
}

.scan{
  position: absolute;
  bottom: 185px;
  right: 0;
 font-weight: lighter;
  
}
    
    
.QR {
  position: absolute;
  bottom: 220px;
  height: 110px;
  right: 35px;
}
    
  
.back{
  height: 40px;
  position: absolute;
  top: 0;
  left: 0;
}




    </style>
    
    
    
      <body>
        
        
      <div class="page"size="A4">
      
      <div class="invoiceImg">
      </div>
        <p class="abs BILL pleft">Bill No. #` + billNo.value + `</p>
        
       <div class = "images">
        <img src="/images/aldenaire.png" class="pineLogo">
        <img src="/images/invoice.png" alt="invoice logo" class="invoice pright">
       </div> 
        <hr class="upperhr">
        <img src="/images/india post.png" alt="invoice logo" class="indiapost abs pleft">
        
        <hr class ="bottomHR">
    <div class="left">
      <h2 class="yoursupplier flex pleft">Your Suplier </h2><p class="companyname pleft">Pine Mount Currency Store</p>
      <p class="addr pleft">Sector 12, Gandhinagar, Gujarat</p>
      <p class="mail pleft abs">E-mail: storepinemountcurrency@gmail.com <br>Mob. no. +91 9316564520</p>
      
    </div>  
      
    <div class="right">
      <p class="client pright abs">Supplied To <br>
      
      <p class="supplied abs">` +
          name.value + `</p>
      <p class="caddr abs pright">` + address.value + `</p>
      <p class="abs pright mail2">` + mail.value + `<br>Mob. No. +91 ` + contact.value + `</p>
    </div>
    <hr class="hr">
    
    <p class="datewala">Date:&nbsp` + date + ` </p>
    
    <table class="maintable">
        <thead>
          
          <tr class="mainTR">
            <th class="linesBottom mainTH">Item Description</th><th class="qty mainTH linesBottom">Quantity</th><th class="mainTH thrate linesBottom">Rate</th><th class="thamount mainTH linesBottom">Amount</th>
          </tr>
        </thead>
          <tbody id="mainspace">
          
      </div>
      
          
      <img src = "/images/QRCODE.png" alt = "QR Code" class = "pright QR">
      
      <p class = "scan pright">Scan for UPI payment</p>
      
      <p class="track abs pleft">Track your order on <br> www.indiapost.gov.in</p>
      
      
      
      <ol class="list abs pleft">
      
      <li class = "liS">Order will be dispatched within three working days.</li>
      <li class = "liS">No COD available.</li>
      <li class = "liS">No return policy.</li>
      <li class = "liS">All disputes under Gandhinagar Judiciary.</li>
      <li class = "liS">Order will not be dispatched untill successful payment.</li>
      
      </ol>
      
      
      
      
      
      
      
    </body>
    <script src="/script.js"></script>
    </html>`
        
        
        
        
        
        
        
      mainList.forEach(function(list) {
        invoice += `<tr><td class ="foritems linesBottom">` + list.itemName + `</td>
        <td class="foritems linesBottom">` + list.quantity + `</td>
        <td class="foritems linesBottom">` + list.rate + `</td>
        <td class="foritems linesBottom">` +list.amount+ `</td>
        </tr>`
      })
      invoice += `<tr>  
      <td>
      <h3 class="total abs pright">Total Amount:&nbsp;Rs. ` + total + ` </h3>
      </td>
      
      
      </tr>`
      invoice += `</tbody></table>`
      
         var popup = window.open("", "_self")
         popup.document.open()
    setTimeout(()=>{
         popup.document.write(invoice)
         }, 1)
    }
     
  
 